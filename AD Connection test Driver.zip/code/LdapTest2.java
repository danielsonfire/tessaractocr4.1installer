import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LdapTest2 {
	
	public static String IP="192.168.54.203";
	public static String PORT="389";
	public static String USERNAME="administrator@eco.com";
	public static String PASSWORD="";
	public static String PROTOCOL="ldap";
	public static String FILTER="(objectclass=group)";
	public static String securityAuthntication="simple";

    public static String ldapUri = "ldap://192.168.54.203:389/";
    public static String usersContainer = "";
    static String[] attrIDs = { "cn","distinguishedName" };
    
    public static String SrearchForUsers = "N";
    
    static int NO_OF_OBJECT_TO_FETCH = 4;
    
    public static boolean allEntriesAlreadyPresent=false;

    public static void main(String args[]) {
 
    	DirContext ctx=getdetails();
    	
    	String tmpdomainname="";
    	String tmpDomainFormated="";
    	if(USERNAME.indexOf("@")>-1){
    		tmpdomainname=USERNAME.substring(USERNAME.indexOf("@")+1);
    		String [] domainsplit= tmpdomainname.split("\\.");
    		if(domainsplit.length>0)
    		{
    			for(int i=0;i<domainsplit.length; i++ )
    			{
    				tmpDomainFormated=tmpDomainFormated+","+("dc="+domainsplit[i]);
    			}
    			tmpDomainFormated=tmpDomainFormated.substring(1);
    		}
    	}
    	
    	usersContainer=PROTOCOL+"://"+IP+":"+PORT+"/"+tmpDomainFormated;
    	BufferedReader br1 = null;
    	NamingEnumeration answer=null;
    	try {
    	br1 = new BufferedReader(new InputStreamReader(System.in));
    	boolean runAgain=true;
    	SearchResult rslt=null;
    	Attributes attrs=null;
    	SearchControls ctls=null;
    	while(runAgain){
    		if(!allEntriesAlreadyPresent){
    		 System.out.print("Enter FILTER, Set value is : "+FILTER+" ");
             String tmpfilter = br1.readLine();
             if(tmpfilter!=null && !tmpfilter.equalsIgnoreCase(""))
            	 FILTER = tmpfilter;
             
             
             if ("q".equalsIgnoreCase(FILTER)) {
                 System.out.println("Exit!");
                 System.exit(0);
             }
             
             

    		 System.out.print("Enter full dn for search, Set value is : "+usersContainer+" ");
             String usercontainer = br1.readLine();
             if(usercontainer!=null && !usercontainer.equalsIgnoreCase(""))
            	 usersContainer = usercontainer;
             
             
             if ("q".equalsIgnoreCase(usersContainer)) {
                 System.out.println("Exit!");
                 System.exit(0);
             }
             
             
             String tmpAttribValues="";
             for(int i=0; i<attrIDs.length; i++)
             {
            	 tmpAttribValues=tmpAttribValues+","+attrIDs[i];
             }
             if(tmpAttribValues.length()>1)
            	 tmpAttribValues=tmpAttribValues.substring(1);
           
             
             System.out.print("Enter comma seprated Attributes to fetch, Set value are : "+tmpAttribValues+" ");
             String enteredAttributes = br1.readLine();
             if(enteredAttributes!=null && !enteredAttributes.equalsIgnoreCase(""))
            	 attrIDs = enteredAttributes.split(",");
             
             
             if ("q".equalsIgnoreCase(enteredAttributes)) {
                 System.out.println("Exit!");
                 System.exit(0);
             }
             
             
             System.out.print("How many object you want to fetch, Set value is : "+NO_OF_OBJECT_TO_FETCH+" ");
             String tempobjectcount = br1.readLine();
             if(tempobjectcount!=null && !tempobjectcount.equalsIgnoreCase("")){
            
             try 
             { 
                 // checking valid integer using parseInt() method 
            	 NO_OF_OBJECT_TO_FETCH=Integer.parseInt(usercontainer); 

             }  
             catch (NumberFormatException e)  
             { 
            	 NO_OF_OBJECT_TO_FETCH=4;
             } 
             }
             
    		}
             ctls = new SearchControls();
             ctls.setReturningObjFlag(true);
             ctls.setReturningAttributes(attrIDs);
             ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);

              answer = ctx.search(usersContainer, FILTER, ctls);
              
              
              
              System.out.print("Getting group Users : "+SrearchForUsers+" ");
              String tmpSearchFOrUser = br1.readLine();
              if(tmpSearchFOrUser!=null && !tmpSearchFOrUser.equalsIgnoreCase(""))
            	  SrearchForUsers = tmpSearchFOrUser;
              
              
              if ("q".equalsIgnoreCase(tmpSearchFOrUser)) {
                  System.out.println("Exit!");
                  System.exit(0);
              }
              
              if(SrearchForUsers.equalsIgnoreCase("Y"))
              {
            	  Attributes attrSet = null;
            	  NamingEnumeration enumNameList=answer;
                  SearchResult sr = (SearchResult)enumNameList.next();
                  attrSet = sr.getAttributes();

                  if (attrSet.size() == 0) {
                    System.out
                      .println(" No group members in the group, hence finish ranging");
                  }

                  for (NamingEnumeration enumResult = attrSet.getAll(); enumResult
                    .hasMore(); )
                  {
                    Attribute attrib = (Attribute)enumResult.next();
                    String getAttrbID = attrib.getID();

                    if (getAttrbID.indexOf("*") > 0) {
                      System.out
                        .println(" all group member results retreived, finish ranging");
                    }
                    System.out.println("\n");
                    System.out.println("\n");
                    for (NamingEnumeration enumName = attrib.getAll(); enumName
                      .hasMore(); )
                    {
                    	
                    	String strDN = (String)enumName.next();
                    	System.out.println(strDN);
                    }
                    System.out.println("\n");
                  }
                
            	  
            	  
            	  
            	  
            	  
              }
              else{
              int tmpCount=0;
              while (answer.hasMore() && tmpCount<NO_OF_OBJECT_TO_FETCH ) {
                  rslt = (SearchResult) answer.next();
                  attrs = rslt.getAttributes();
                  for(int i=0;i<attrIDs.length; i++){
                	  System.out.println(attrIDs[i]+": "+attrs.get(attrIDs[i]));
                  }
                  System.out.println("\n");
                  tmpCount++;
                 
             }
    	
              System.out.println("\n\n\n\n");
              }
              
    	}
            ctx.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
	public static DirContext getdetails() {

        BufferedReader br = null;
        DirContext context=null;
        try {

            br = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("Enter Q or q to quit anytime \n\n");
            
            boolean runAgain=true;
            while (runAgain) {
              
            	if(!allEntriesAlreadyPresent){
            		
            		
            	System.out.print("Enter Security authntication, Set value is : " + securityAuthntication+" " );
                 String tempsecurityAuthntication = br.readLine();
                 if(tempsecurityAuthntication!=null && !tempsecurityAuthntication.equalsIgnoreCase(""))
                  securityAuthntication = tempsecurityAuthntication;
                     
                     if ("q".equalsIgnoreCase(securityAuthntication)) {
                         System.out.println("Exit!");
                         System.exit(0);
                     }
            		
            		
                System.out.print("Enter protocol, Set value is : "+PROTOCOL+" ");
                String tmpprotocol = br.readLine();
                if(tmpprotocol!=null && !tmpprotocol.equalsIgnoreCase(""))
                	PROTOCOL = tmpprotocol;
                
                
                if ("q".equalsIgnoreCase(PROTOCOL)) {
                    System.out.println("Exit!");
                    System.exit(0);
                }
                
                
                System.out.println("Enter Active directory ip, Set value is :"+IP+" ");
                
                
                String tempIP = br.readLine();
                if(tempIP!=null && !tempIP.equalsIgnoreCase(""))
                	IP=tempIP;
                	
                if ("q".equalsIgnoreCase(IP)) {
                    System.out.println("Exit!");
                    System.exit(0);
                }
                
                
                System.out.print("Enter Active directory port, Set value is : " + PORT+" " );
                String tempPort = br.readLine();
                if(tempPort!=null && !tempPort.equalsIgnoreCase(""))
                PORT = tempPort;
                
                if ("q".equalsIgnoreCase(PORT)) {
                    System.out.println("Exit!");
                    System.exit(0);
                }
                
                System.out.print("Enter user name and domain format username@domain, Set value is : "+USERNAME+" ");
                
                String tempUsername = br.readLine();
                if(tempUsername!=null && !tempUsername.equalsIgnoreCase(""))
                    USERNAME = tempUsername;
                
                
                if ("q".equalsIgnoreCase(USERNAME)) {
                    System.out.println("Exit!");
                    System.exit(0);
                }
                
                System.out.print("Enter Paasword, Set value is : "+PASSWORD+" ");
                String tempPasword = br.readLine();
                if(tempPasword!=null && !tempPasword.equalsIgnoreCase(""))
                    PASSWORD = tempPasword;
                
                

                if ("q".equalsIgnoreCase(PASSWORD)) {
                    System.out.println("Exit!");
                    System.exit(0);
                }
            	}
                try{
                	context=connect();
                runAgain=false;
                } catch (Exception e) {
					
				}
            }
            

        } catch (IOException e) {
            e.printStackTrace();
        } finally {

        }
        return context;
    }
	
	public static DirContext connect() throws Exception{
	
		System.out.println("Before Authentication....");
		Hashtable<String, String> env = new Hashtable<String, String>(11);
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.REFERRAL, "follow");
		String providerUrl = PROTOCOL+"://"+IP+":"+PORT;
		env.put(Context.PROVIDER_URL, providerUrl);
		env.put(Context.SECURITY_AUTHENTICATION, securityAuthntication);
		env.put(Context.SECURITY_PRINCIPAL, USERNAME);
		env.put(Context.SECURITY_CREDENTIALS, PASSWORD);
		DirContext context = new InitialDirContext(env);
		System.out.println("Succesful Authenticated....");
		return context;
	
	}
}